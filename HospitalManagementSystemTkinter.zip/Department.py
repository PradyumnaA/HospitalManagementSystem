#Hospital's #import modules
from tkinter import *
import sqlite3 as s
import tkinter.messagebox
#connect to the database
con=s.connect("department1.db")
print("Succesfully connected")
#cursor to
c=con.cursor()
#creating a table
#data=c.execute("Create table department (d_id Text Primary Key,d_name Text)")
#tkinter window
class Department:
    def __init__(self,master):
        self.master=master
        #creating the frames in the master
        self.left=Frame(master,width=800,height=720,bg='lightgreen')
        self.left.pack(side=LEFT)
        self.right=Frame(master,width=400,height=720,bg='steelblue')
        self.right.pack(side=RIGHT)
        self.heading=Label(self.left,text="Department database",font=('arial 40 bold'),fg='dark red')
        self.heading.place(x=0,y=0)


        #labels for the window
        #Hospital's  name
        self.d_id=Label(self.left,text="Department's id",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.d_id.place(x=0,y=100)
        #Hospital's  address
        self.d_name=Label(self.left,text="Department's Name",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.d_name.place(x=0,y=140)
        #Hospital's  location


        #entries for all labels


        self.ent_d_id=Entry(self.left,width=30)
        self.ent_d_id.place(x=250,y=100)

        self.ent_d_name=Entry(self.left,width=30)
        self.ent_d_name.place(x=250,y=140)


        #button to perform a command
        self.submit=Button(self.left,text="Add Department",width=20,height=2,bg='steelblue',fg='purple',command=self.add_appointment)
        self.submit.place(x=300,y=340)

        self.box=Text(self.right,width=50,height=40)
        self.box.place(x=20,y=30)



        #function to call when submit button is clicked
    def add_appointment(self):
        #getting values from the user input
        self.val1=self.ent_d_id.get()
        self.val2=self.ent_d_name.get()

        #checking whether the user gives input or not if he doesnot the
        if self.val1 == '' or self.val2 == '':
            tkinter.messagebox.showinfo("Warning","Please Fill Up All Boxes")
        else:
            #sql="INSERT INTO 'doctor' (name,age,gender,location,scheduled_time) VALUES(?,?,?,?,?)"
            #c.execute(sql,(self.val1,self.val2,self.val3,self.val4,self.val5))
            #con.commit()
            tkinter.messagebox.showinfo("Congradulations we have Succesfully updated database")
            self.box.insert(END,'Database entered')


def main():

#creating the object
    root=Tk()
    b=Department(root)
#resolution of the window
    root.geometry("1200x720+0+0")
#preventint the resize feature
    root.resizable(False,False)
    root.mainloop()
#end the loop
