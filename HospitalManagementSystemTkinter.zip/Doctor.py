#Doctor's#import modules
from tkinter import *
import sqlite3 as s
import tkinter.messagebox
#connect to the database
con=s.connect("Doctor1.db")
print("Succesfully connected")
#cursor to
c=con.cursor()
#creating a table
#data=c.execute("Create table doctor (Doc_id Text Primary key,Name Text,Age text,Gender Text,Location Text,scheduled_time Text,Qualification Text,Phone Number  Integer(10),Joining_date Text)")
#tkinter window
class Doctor:
    def __init__(self,master):
        self.master=master
        #creating the frames in the master
        self.left=Frame(master,width=800,height=720,bg='lightgreen')
        self.left.pack(side=LEFT)
        self.right=Frame(master,width=400,height=720,bg='steelblue')
        self.right.pack(side=RIGHT)
        self.heading=Label(self.left,text="Doctor database",font=('arial 40 bold'),fg='dark red')
        self.heading.place(x=0,y=0)


        #labels for the window
	    #Doctor's id
	   # self.Doc_id=Label(self.left,text="Doctor'sName",font=('arial 18 bold'),fg='black',bg='lightgreen'))
	    #self.Doc_id.place(x=0,y=60)
        #Doctor's name
        self.name=Label(self.left,text="Doctor'sName",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.name.place(x=0,y=100)
        #Doctor's age
        self.age=Label(self.left,text="Age",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.age.place(x=0,y=140)
        #Doctor's gender
        self.gender=Label(self.left,text="Gender",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.gender.place(x=0,y=180)
        #Doctor's location
        self.location=Label(self.left,text="Location",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.location.place(x=0,y=220)
        #Doctor's admiission date

        #Doctor's phone number
        #labels for the window
        self.phone=Label(self.left,text="Phone Number",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.phone.place(x=0,y=260)


        #Doctor'sQualification
        self.qualification=Label(self.left,text="Qualification",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.qualification.place(x=0,y=300)


        #entries for all labels
	    #self.ent_doc_id=Entry(self.left,width=30)
	    #self.ent_doc_id.place(x=250,y=60)
        self.ent_name=Entry(self.left,width=30)
        self.ent_name.place(x=250,y=100)

        self.ent_age=Entry(self.left,width=30)
        self.ent_age.place(x=250,y=140)

        self.ent_gender=Entry(self.left,width=30)
        self.ent_gender.place(x=250,y=180)

        self.ent_location=Entry(self.left,width=30)
        self.ent_location.place(x=250,y=220)

        self.ent_qualification=Entry(self.left,width=30)
        self.ent_location.place(x=250,y=220)

        self.ent_time=Entry(self.left,width=30)
        self.ent_time.place(x=250,y=260)
        self.ent_phone=Entry(self.left,width=30)
        self.ent_phone.place(x=250,y=300)
        #button to perform a command
        self.submit=Button(self.left,text="Add Appointment",width=20,height=2,bg='steelblue',fg='purple',command=self.add_appointment)
        self.submit.place(x=300,y=340)

        self.box=Text(self.right,width=50,height=40)
        self.box.place(x=20,y=30)



        #function to call when submit button is clicked
    def add_appointment(self):
        #getting values from the user input
        #self.val1=self.ent_doc_id.get()
        self.val2=self.ent_name.get()
        self.val3=self.ent_age.get()
        self.val4=self.ent_gender.get()
        self.val5=self.ent_location.get()
        self.val6=self.ent_time.get()
        self.val7=self.ent_phone.get()
        #checking whether the user gives input or not if he doesnot the
        if self.val2 == '' or self.val3 == '' or self.val4 == '' or self.val5 == ''  or  self.val6 == '' or  self.val7 == '':
            tkinter.messagebox.showinfo("Warning","Please Fill Up All Boxes")
        else:
            sql="INSERT INTO 'doctor' ( name,age,gender,location,scheduled_time,Phone) VALUES(?,?,?,?,?,?)"
            c.execute(sql,(self.val2,self.val3,self.val4,self.val5,self.val6,self.val7))
            con.commit()
            tkinter.messagebox.showinfo("Congradulations we have Succesfully updated database")
            self.box.insert(END,'Appointment fixed')


def main():
#creating the object
    root=Tk()
    b=Doctor(root)
#resolution of the window
    root.geometry("1200x720+0+0")
#preventint the resize feature
    root.resizable(False,False)
    root.mainloop()
#end the loop
