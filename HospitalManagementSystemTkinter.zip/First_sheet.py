from tkinter import*
import Appointment
import Department
import Doctor
import Employee
import Hospital
import Medical_record
#import delete_Appointment

def Main1():
    Appointment.main()
def Main2():
    Doctor.main()
def Main3():
    Department.main()
def Main4():
    Employee.main()
def Main5():
    Hospital.main()
def Main6():
    Medical_record.main()
'''def Main7():
    delete_Appointment.main()
'''

root=Tk()
topFrame=Frame(root)
topFrame.pack()
bottomFrame=Frame(root)
bottomFrame.pack(side=BOTTOM)
button1=Button(topFrame,text="Add Patient",fg="Red")
button1.place(x=100,y=0)
button2=Button(text="Add Doctor",fg="Green")
button2.place(x=120,y=0)
button3=Button(bottomFrame,text="Department",fg="Red")
button3.place(x=140,y=0)
button4=Button(bottomFrame,text="Employee",fg="Purple")
button5=Button(bottomFrame,text="Add Hospital",fg="Yellow",bg="Magenta")
button6=Button(bottomFrame,text="Medical_record",fg="Blue",bg="Yellow")
#button7=Button(bottomFrame,text="delete_appointment",fg="Brown",bg="Black")
button1.pack(side=LEFT)
button2.pack(side=LEFT)
button3.pack(side=LEFT)
button4.pack(side=LEFT)
button5.pack(side=LEFT)
button6.pack(side=LEFT)
#button7.pack(side=LEFT)
'''
the above 3 commands i.e pack command is used to display image of button on the screen
'''


#dear compiler do 1 thing button1 action is taken from main function
button1.config(command=Main1)
button2.config(command=Main2)
button3.config(command=Main3)
button4.config(command=Main4)
button5.config(command=Main5)
button6.config(command=Main6)
#button7.config(command=Main7)
root.mainloop()
