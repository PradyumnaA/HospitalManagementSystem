#Employee's #import modules
from tkinter import *
import sqlite3 as s
import tkinter.messagebox
#connect to the database
con=s.connect("employee.db")
print("Succesfully connected")
#cursor to
c=con.cursor()
#creating a table
#data=c.execute("Create table Employee (E_id Text Primary Key,Name Text,Age text,Gender Text,Address Text,Domain Text,Joining_date  Text(8),Phone Integer(10))")
#tkinter window
class Employee:
    def __init__(self,master):
        self.master=master
        #creating the frames in the master
        self.left=Frame(master,width=800,height=720,bg='lightgreen')
        self.left.pack(side=LEFT)
        self.right=Frame(master,width=400,height=720,bg='steelblue')
        self.right.pack(side=RIGHT)
        self.heading=Label(self.left,text="Doctor database",font=('arial 40 bold'),fg='dark red')
        self.heading.place(x=0,y=0)


        #labels for the window
        #Employee's  name
        self.e_id=Label(self.left,text="Employee's ID",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.e_id.place(x=0,y=100)
        #Employee's  age
        self.e_name=Label(self.left,text="Employee's Name",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.e_name.place(x=0,y=140)
        #Employee's  gender
        self.e_age=Label(self.left,text="Age",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.e_age.place(x=0,y=180)
        #Employee's  location
        self.e_gender=Label(self.left,text="Gender",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.e_gender.place(x=0,y=220)
        #Employee's  admiission date

        #Employee's  phone number
        #labels for the window
        self.address=Label(self.left,text="Address",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.address.place(x=0,y=260)


        #Employee's Domain
        self.domain=Label(self.left,text="Domain",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.domain.place(x=0,y=300)
        #Employee's Joining dat
        self.Joining_date=Label(self.left,text="Joining_date",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.Joining_date.place(x=0,y=340)
        #Phone
        self.Phone=Label(self.left,text="Phone_number",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.Phone.place(x=0,y=380)


        #entries for all labels


        self.ent_id=Entry(self.left,width=30)
        self.ent_id.place(x=250,y=100)

        self.ent_name=Entry(self.left,width=30)
        self.ent_name.place(x=250,y=140)

        self.ent_age=Entry(self.left,width=30)
        self.ent_age.place(x=250,y=180)

        self.ent_gender=Entry(self.left,width=30)
        self.ent_gender.place(x=250,y=220)

        self.ent_address=Entry(self.left,width=30)
        self.ent_address.place(x=250,y=260)

        self.ent_domain=Entry(self.left,width=30)
        self.ent_domain.place(x=250,y=300)

        self.ent_joining_date=Entry(self.left,width=30)
        self.ent_joining_date.place(x=250,y=340)

        self.ent_Phone=Entry(self.left,width=30)
        self.ent_Phone.place(x=250,y=380)
        #button to perform a command
        self.submit=Button(self.left,text="Add Entry",width=20,height=2,bg='steelblue',fg='purple',command=self.add_appointment)
        self.submit.place(x=300,y=500)

        self.box=Text(self.right,width=50,height=40)
        self.box.place(x=20,y=30)



        #function to call when submit button is clicked
    def add_appointment(self):
        #getting values from the user input
        self.val1=self.ent_id.get()
        self.val2=self.ent_name.get()
        self.val3=self.ent_age.get()
        self.val4=self.ent_gender.get()
        self.val5=self.ent_address.get()
        self.val6=self.ent_domain.get()
        self.val7=self.ent_joining_date.get()
        self.val8=self.ent_Phone.get()
        #checking whether the user gives input or not if he doesnot the
        if self.val1 == '' or self.val2 == '' or self.val3 == '' or self.val4 == ''  or  self.val5 == '' or  self.val6 == '' or self.val7 == ''or self.val8 == '':
            tkinter.messagebox.showinfo("Warning","Please Fill Up All Boxes")
        else:
            sql="INSERT INTO  'Employee' (E_id,Name,Age,Gender,Address,Domain,Joining_date,Phone) VALUES(?,?,?,?,?,?,?,?)"
            c.execute(sql,(self.val1,self.val2,self.val3,self.val4,self.val5,self.val6,self.val7,self.val8))
            con.commit()
            tkinter.messagebox.showinfo("Congradulations we have Succesfully updated database")
            self.box.insert(END,'Database Entered')

def main():

#creating the object
    root=Tk()
    b=Employee(root)
#resolution of the window
    root.geometry("1200x720+0+0")
#preventint the resize feature
    root.resizable(False,False)
    root.mainloop()
#end the loop
