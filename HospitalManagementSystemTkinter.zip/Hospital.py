#Hospital's #import modules
from tkinter import *
import sqlite3 as s
import tkinter.messagebox
#connect to the database
con=s.connect("Hospital1.db")
print("Succesfully connected")
#cursor to
c=con.cursor()
#creating a table
#data=c.execute("Create table Hospital1 (Hos_id INTEGER Primary Key AUTOINCREMENT,Name Text,Address text,Location Text,Phone Number(10),Domain Text)")
#tkinter window
class Hospital:
    def __init__(self,master):
        self.master=master
        #creating the frames in the master
        self.left=Frame(master,width=800,height=720,bg='lightgreen')
        self.left.pack(side=LEFT)
        self.right=Frame(master,width=400,height=720,bg='steelblue')
        self.right.pack(side=RIGHT)
        self.heading=Label(self.left,text="Hospital database",font=('arial 40 bold'),fg='dark red')
        self.heading.place(x=0,y=0)


        #labels for the window
        #Hospital's  name
        self.name=Label(self.left,text="Hospital's Name",font=('arial 15 bold'),fg='black',bg='lightgreen')
        self.name.place(x=0,y=100)
        #Hospital's  address
        self.addr=Label(self.left,text="Address",font=('arial 15 bold'),fg='black',bg='lightgreen')
        self.addr.place(x=0,y=140)
        #Hospital's  location
        self.location=Label(self.left,text="Location",font=('arial 15 bold'),fg='black',bg='lightgreen')
        self.location.place(x=0,y=180)

        #Hospital's  phone number
        #labels for the window
        self.phone=Label(self.left,text="Phone Number",font=('arial 15 bold'),fg='black',bg='lightgreen')
        self.phone.place(x=0,y=210)


        #Hospital's Domain
        self.domain=Label(self.left,text="Domain",font=('arial 15 bold'),fg='black',bg='lightgreen')
        self.domain.place(x=0,y=250)


        #entries for all labels


        self.ent_name=Entry(self.left,width=30)
        self.ent_name.place(x=250,y=100)

        self.ent_address=Entry(self.left,width=30)
        self.ent_address.place(x=250,y=140)

        self.ent_location=Entry(self.left,width=30)
        self.ent_location.place(x=250,y=180)

        self.ent_phone=Entry(self.left,width=30)
        self.ent_phone.place(x=250,y=220)

        self.ent_domain=Entry(self.left,width=30)
        self.ent_domain.place(x=250,y=260)

        #button to perform a command
        self.submit=Button(self.left,text="Add Hospital",width=20,height=2,bg='steelblue',fg='purple',command=self.add_appointment)
        self.submit.place(x=300,y=340)

        self.box=Text(self.right,width=50,height=40)
        self.box.place(x=20,y=30)



        #function to call when submit button is clicked
    def add_appointment(self):
        #getting values from the user input
        self.val1=self.ent_name.get()
        self.val2=self.ent_address.get()
        self.val3=self.ent_location.get()
        self.val4=self.ent_phone.get()
        self.val5=self.ent_domain.get()
        #checking whether the user gives input or not if he doesnot the
        if self.val1 == '' or self.val2 == '' or self.val3 == '' or self.val4 == ''  or  self.val5 == '':
            tkinter.messagebox.showinfo("Warning","Please Fill Up All Boxes")
        else:
            sql="INSERT INTO 'Hospital1' (Name,Address,Location,Phone,Domain) VALUES(?,?,?,?,?)"
            c.execute(sql,(self.val1,self.val2,self.val3,self.val4,self.val5))
            con.commit()
            tkinter.messagebox.showinfo("Congradulations we have Succesfully updated database")
            self.box.insert(END,'Appointment fixed')




def main():


#creating the object
    root=Tk()
    b=Hospital(root)
#resolution of the window
    root.geometry("1200x720+0+0")
#preventint the resize feature
    root.resizable(False,False)
    root.mainloop()
#end the loop
