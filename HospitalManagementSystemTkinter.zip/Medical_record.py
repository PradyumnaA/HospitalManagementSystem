

#Hospital's #import modules
from tkinter import *
import sqlite3 as s
import tkinter.messagebox
#connect to the database
con=s.connect("Medical_record.db")
print("Succesfully connected")
#cursor to
c=con.cursor()
#creating a table
#data=c.execute("Create table Medical_record (date_of_admission text,problem text,m_id text)")
#tkinter window
class Application:
    def __init__(self,master):
        self.master=master
        #creating the frames in the master
        self.left=Frame(master,width=800,height=720,bg='lightgreen')
        self.left.pack(side=LEFT)
        self.right=Frame(master,width=400,height=720,bg='steelblue')
        self.right.pack(side=RIGHT)
        self.heading=Label(self.left,text="Medical Record",font=('arial 40 bold'),fg='dark red')
        self.heading.place(x=0,y=0)


        #labels for the window
        #Hospital's  name
        self.date_of_admission=Label(self.left,text="Hospital's Date of Admission",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.date_of_admission.place(x=0,y=100)
        #Hospital's  address
        self.Problem=Label(self.left,text="Problem",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.Problem.place(x=0,y=140)
        #Hospital's  location
        self.M_id=Label(self.left,text="Medical_Record_id",font=('arial 18 bold'),fg='black',bg='lightgreen')
        self.M_id.place(x=0,y=180)
        #Hospital's  admiission date

        #Hospital's  phone number


        self.ent_date_of_Admisssion=Entry(self.left,width=30)
        self.ent_date_of_Admisssion.place(x=350,y=100)

        self.ent_Problem=Entry(self.left,width=30)
        self.ent_Problem.place(x=350,y=140)

        self.ent_M_id=Entry(self.left,width=30)
        self.ent_M_id.place(x=350,y=180)

        #button to perform a command
        self.submit=Button(self.left,text="Add Patients record",width=20,height=2,bg='steelblue',fg='purple',command=self.add_appointment)
        self.submit.place(x=300,y=340)

        self.box=Text(self.right,width=50,height=40)
        self.box.place(x=20,y=30)



        #function to call when submit button is clicked
    def add_appointment(self):
        #getting values from the user input
        self.val1=self.ent_date_of_Admisssion.get()
        self.val2=self.ent_Problem.get()
        self.val3=self.ent_M_id.get()
        if self.val1 == '' or self.val2 == '' or self.val3 == '':
            tkinter.messagebox.showinfo("Warning","Please Fill Up All Boxes")
        else:
            sql="INSERT INTO 'Medical_record' (date_of_admission,Problem,M_id) VALUES(?,?,?)"
            c.execute(sql,(self.val1,self.val2,self.val3))
            #con.commit()
            tkinter.messagebox.showinfo("Congradulations we have Succesfully updated database")
            self.box.insert(END,'Record Updated')

def main():

#creating the object
    root=Tk()
    b=Application(root)
#resolution of the window
    root.geometry("1200x720+0+0")
#preventint the resize feature
    root.resizable(False,False)
    root.mainloop()
#end the loop
